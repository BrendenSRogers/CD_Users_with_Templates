from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index),
    path('dojos/create', views.create_a_dojo),
    path('ninjas/create', views.create_a_ninja),
]
